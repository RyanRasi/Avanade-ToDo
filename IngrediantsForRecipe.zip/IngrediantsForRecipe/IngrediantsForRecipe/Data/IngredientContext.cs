﻿using IngrediantsForRecipe.Models;
using Microsoft.EntityFrameworkCore;

namespace IngrediantsForRecipe.Data
{
    public class IngredientContext : DbContext
    {
        public IngredientContext(DbContextOptions<IngredientContext> options) : base(options)
        {
        }
        public DbSet<IngredientItem> IngredientItems { get; set; }

    }
}
